﻿using System;

namespace PsHelloAzure.Models
{
    public class ShowModel
    {
        public string Uri { get; set; }
        public string Analysis { get; set; }
    }
}
