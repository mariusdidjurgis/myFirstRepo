. "$PSScriptRoot\..\src\ReportingServicesReport.ps1"
Import-Module "$PSScriptRoot\..\src\ReportingServicesTools\0.0.4.7\ReportingServicesTools.psd1"

function Update-ValueInFile {
    param(
        [string]$file,
        [string]$currentvalue,
        [string]$newvalue
    )
    
    $content = Get-Content -Path $file

    $updated = $content.Replace($currentvalue, $newvalue)

    Set-Content -Path $file -Value $updated
}

#$rsservername = "wsp2628c" # Old SSRS 2008 server
$rsservername = "wsp3068c" # New SSRS 2016 server

# Describe 'Files' {
#     It 'Should enumerate some files' {

#         $path = "/Internal Reports"
#         $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject\SSRS\TEST_ReportIncorrectOrders'
#         $reportname = 'ReportIncorrectOrders_7_1_TEST'
#         $fullpath = "$path/$reportname"

#         # $subreportfiles = Get-ChildItem -Path "$testprojectPath\" -Filter "*.rdl" -Exclude "$reportname.rdl"
#         $subreportfiles = Get-ChildItem -Path "$testprojectPath" -File -Filter "*.rdl" -Recurse -Exclude "$reportname.rdl"

#         foreach ($file in $subreportfiles) {
#             # if($file.ToString().StartsWith($reportname) ) {
#             #     continue
#             # }
#             write-host $file.FullName
#             Write-Host $file.ToString()
#         }

#         $subreportfiles | Should -BeGreaterThan 3
#     }
# }

Describe 'Test update variable' {
    It 'Returns name' {
        $report = "/Internal Reports/ReportIncorrectOrders_7_1_TEST"
        $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject\SSRS\TEST_ReportIncorrectOrders'
        $reportname = 'ReportIncorrectOrders_7_1_TEST'
        $testreportpath = "$testprojectPath\$reportname.rdl"
        $name = Update-ValuesForParameterInReport -rsservername $rsservername -path $report -localpath $testreportpath
        write-host $name
    }
}

Describe 'ReportServer basics' {
    Set-Variable -Name "isrunningasatest" -Value $true -Scope Global

    It 'Should return the full uri if sending in the servername' {
        $expected = "http://wsp3068c.sebank.se/reportserver"

        Get-RsServerPath -rsservername $rsservername | Should Be $expected
    }

    It 'Should return the full wsdl uri if sending in the servername and a fullwsdl switch' {
        $expected = "http://wsp3068c/ReportServer/ReportService2010.asmx?WSDL"
        # $expected = "http://wsp3068c/ReportServer/ReportExecution2005.asmx?WSDL"
                
        Get-RsServerPath -rsservername $rsservername -fullwsdl | Should Be $expected
    }

    It 'Should return the full wsdl uri for 2005 if sending in the servername, fullwsdl switch and version2005 switch' {
        $expected = "http://wsp3068c/ReportServer/ReportService2005.asmx?WSDL"
                        
        Get-RsServerPath -rsservername $rsservername -version2005 -fullwsdl | Should Be $expected
    }

    It 'Getting content from internal reports path should get over 100 reports' {
        #Here the path is not case sensitive but should be treated as such
        $path = 'Internal Reports'

        $rscontent = Get-FolderContentFromRs -rsservername $rsservername -path $path
        $rscontent.Count | Should -BeGreaterThan 100
    }

    It 'Gets the foldername' {
        $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject\SSRS\TEST_ReportIncorrectOrders'
        $expected = "TEST_ReportIncorrectOrders"
        $actual = ""

        $actual = $testprojectPath.Substring($testprojectPath.LastIndexOf("\")+1)
        $actual | Should Be $expected

    }

    # It 'Should normalize a reportserver folder path that does not start with /' {
    #     $path = "testing"
    #     $expected = "/testing"

    #     Get-NormalizedRsFolderPath -path $path | Should Be $expected
    # }

    # It 'Should not normalize a reportserver folder path that start with /' {
    #     $path = "/testing"
    #     $expected = "/testing"

    #     Get-NormalizedRsFolderPath -path $path | Should Be $expected
    # }

    Remove-Variable -Name "isrunningasatest" -Scope Global -Force
}


Describe 'Get subreports' {
    It 'Should list several files' {
        $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject\SSRS\TEST_ReportIncorrectOrders'
        $reportname = "ReportIncorrectOrders_7_1_TEST.rdl"
        $reportfileending = ".rdl"

        Write-Host "Adding subreports if any are found under $testprojectPath with *$reportfileending filter"
    
        $subreportfiles = Get-ChildItem -Path $testprojectPath -Filter "*$reportfileending"
        #$subreportfiles = Get-ChildItem -Path $testprojectPath -Filter "*$reportfileending" -Exclude $reportname
        #$subreportfiles = Get-ChildItem -Path $testprojectPath -Filter "*$reportfileending"

        # Now update the subreports if there are any
        foreach ($subreportfile in $subreportfiles) {
            
            if($subreportfile.Name -eq $reportname) {
                continue
            }
            Write-Host "Updating the subreport $($subreportfile.FullName)"       
        }
    }
}

Describe 'Export subscription' {
    It 'Exports a subscription' {
        $server = "wsp3068c"
        $path = "Internal Reports/ReportTAPaymentsToAndFromIMABFunds_7_1"
        $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject\SSRS\TEST_ReportIncorrectOrders'
        $subscriptionfile = "$testprojectPath\ReportTAPaymentsToAndFromIMABFunds_7_1.subscription.$server.xml"
        Get-SubscriptionsForReport -rsservername $server -path $path  | Export-RsSubscriptionXml $subscriptionfile
    }
}

# Describe 'Reporting Service Item Internal Reports/TAOrdersPerCustomer_7_1' {
#     #Observe that the path is case sensitive!
#     $path = "Internal Reports/TAOrdersPerCustomer_7_1"
#     $rsservername = "wsp3069c"
    
#     It 'Getting subscriptions from the report should return one subscription' {
#         $subscriptions = Get-SubscriptionsForReport -rsservername $rsservername -path $path
#         @($subscriptions).Count | Should Be 1
#         $subscriptions.EventType | Should Be "TimedSubscription"
#         $subscriptions.IsDataDriven | Should Be $true
#         $subscriptions.Status | Should Be "New Subscription"
#         $subscriptions.DeliverySettings.Extension | Should Be "Report Server FileShare"
#     }

#     # It 'Getting data sources from the report should return two sources with one invalid' {
#     #     $datasources = Get-DataSourcesFromReport -rsservername $rsservername -path $path
#     #     $datasources.Count | Should -Be 2
#     #     $datasources[0].Name | Should Be "eCM_Report_DB"
#     #     #$datasources[0].Item.Reference | Should Be "/Data Sources/eCM_Report_DB"
#     #     $datasources[0].Item.Reference | Should Be $null
#     #     $datasources[1].Name | Should Be "eCM_Local_DB"
#     #     $datasources[1].Item.Reference | Should Be "/Data Sources/eCM_Local_DB"
#     # }    
# }

# Describe 'Reporting Service Item Internal Reports/TAFundHoldingsPerFundAndValuationDate_7_1' {
#     #Observe that the path is case sensitive!
#     $path = "Internal Reports/TAFundHoldingsPerFundAndValuationDate_7_1"
#     #$rsservername = "wsp2628c"

#     It 'Getting data sources from the report should return two sources' {
#         $datasources = Get-DataSourcesFromReport -rsservername $rsservername -path $path
#         $datasources.Count | Should -Be 3
#         $datasources[0].Name | Should Be "eCM_Report_DB"
#         #$datasources[0].Item.Reference | Should Be "/Data Sources/eCM_Report_DB"
#         $datasources[0].Item.Reference | Should Be $null
#         $datasources[1].Name | Should Be "eCM_Local_DB"
#         $datasources[1].Item.Reference | Should Be "/Data Sources/eCM_Local_DB"
#         $datasources[2].Name | Should Be "XML"
#         $datasources[2].Item.Reference | Should Be "/Data Sources/XML"
#     }
# }

# Describe 'Reporting Service Item Internal Reports/TAFundHoldingsPerFundAndValuationDate_7_1_TESTPROJECT' {
#     #Observe that the path is case sensitive!
#     $path = "Internal Reports"
#     #$rsservername = "wsp2628c"

#     Context "Write-RsCatalogItem with parameters"{
#         $localPath =   (Get-Item -Path ".\").FullName  + '\testproject'

#         It "Should upload a local report in Report Server" {
#             $localReportPath = $localPath + '\TAFundHoldingsPerFundAndValuationDate_7_1_TESTPROJECT.rdl'
#             Write-ReportToRsServer -rsservername $rsservername -path $path -localpath $localReportPath -Description 'ThisIsATestProject'
#             #
#             # $uploadedReport = (Get-RsFolderContent -RsFolder $folderPath ) | Where-Object TypeName -eq 'Report'
#             # $uploadedReport.Name | Should Be 'emptyReport'
#             # $uploadedReport.Description | Should Be 'newDescription'
#         }
#         # Removing folders used for testing
#         #Remove-RsCatalogItem -RsFolder $folderPath -Confirm:$false
#     }

# }

# Describe 'Reporting Service Item Internal Reports/TAFundHoldingsPerFundAndValuationDateText_7_1_TESTPROJECT' {
#     #Observe that the path is case sensitive!
#     $path = "Internal Reports"
#     #$rsservername = "wsp2628c"

#     Context "Write-RsCatalogItem with parameters"{
#         $localPath =   (Get-Item -Path ".\").FullName  + '\testproject'

#         It "Should upload a local report in Report Server" {
#             $localReportPath = $localPath + '\TAFundHoldingsPerFundAndValuationDateText_7_1_TESTPROJECT.rdl'
#             Write-ReportToRsServer -rsservername $rsservername -path $path -localpath $localReportPath -Description 'ThisIsATestProject'
#             #
#             # $uploadedReport = (Get-RsFolderContent -RsFolder $folderPath ) | Where-Object TypeName -eq 'Report'
#             # $uploadedReport.Name | Should Be 'emptyReport'
#             # $uploadedReport.Description | Should Be 'newDescription'
#         }

#         # Removing folders used for testing
#         #Remove-RsCatalogItem -RsFolder $folderPath -Confirm:$false
#     }
# }

# Used to install subscriptions to installed reports for test purpose to see that the installationscript is fully functional
Describe 'Install report and subcriptions for TAOrdersPerCustomer_7_1_TEST in wsp3068c' {
    $path = "/Internal Reports"
    $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject\SSRS\TEST_ReportIncorrectOrders'
    $reportname = 'TAOrdersPerCustomer_7_1_TEST'

    It 'Should install the report TAOrdersPerCustomer_7_1_TEST to dev' {

        $testreportpath = "$testprojectPath\$reportname.rdl"

        Write-Host "Uploading the report $testreportpath to $path"

        Write-ReportToRsServer -rsservername $rsservername -path $path -localpath $testreportpath -Description 'ThisIsATestProjectInstalledByScript-Original'
    }

    # It 'Should install the FileShare subscription SubTA_OrdersPerCustomerPDFAndExcel' {
    #     $fullpath = "$path/$reportname"
    #     $subscriptionfile = "$testprojectPath\SubTA_OrdersPerCustomerPDFAndExcel.subscription.json"

    #     New-SubscriptionForReport -rsservername $rsservername -path $fullpath -subscriptionfile $subscriptionfile
    # }

    It 'Should install the FileShare subscription SubTA_OrdersPerCustomerExcel' {
        $fullpath = "$path/$reportname"
        $subscriptionfile = "$testprojectPath\SubTA_OrdersPerCustomerExcel.subscription.json"

        New-SubscriptionForReport -rsservername $rsservername -path $path -subscriptionfile $subscriptionfile
    }    
}

Describe 'Update default parameters for report ReportTAPaymentsToAndFromIMABFunds_7_1' {
    Set-Variable -Name "isrunningasatest" -Value $true -Scope Global
    $path = "/Internal Reports"
    $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject\SSRS\TEST_ReportIncorrectOrders'
    $reportname = 'ReportTAPaymentsToAndFromIMABFunds_7_1'

    It 'Should update defaultvalues for ReportParameters' {
        $testreportpath = "$testprojectPath\$reportname.rdl"
        $fullpath = "$path/$reportname"

        Write-Host "Updating the defaultvalue for reportparameters in the report $testreportpath at $path"
        Update-ValuesForParameterInReport -rsservername $rsservername -fullpath $fullpath -localpath $testreportpath
    }    
}

# Run a complete installation and removal of a test report based on each available function
Describe 'Install Reporting Service Item /Internal Reports/ReportIncorrectOrders_7_1_TEST' {
    Set-Variable -Name "isrunningasatest" -Value $true -Scope Global
    $path = "/Internal Reports"
    $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject\SSRS\TEST_ReportIncorrectOrders'
    $reportname = 'ReportIncorrectOrders_7_1_TEST'
    $batchidtoken = "#{BATCHIDTOKEN}#"
    $toemailadresstoken = "#{EMAILTOADRESSTOKEN}#"
    $filesharetoken = "#{FILESHARETOKEN}#"

    Context 'ReportIncorrectOrders_7_1_TEST is not installed on the server' {
        It 'Should not find ReportIncorrectOrders_7_1_TEST in /Internal Reports' {
            Write-Host "Checking if we can find the report $reportname under $path"

            $rscontent = Get-FolderContentFromRs -rsservername $rsservername -path $path -reportname $reportname
            $rscontent.Count | Should Be 0
        }
    }

    Context 'ReportIncorrectOrders_7_1_TEST is getting installed on the server' {
        It 'Should upload ReportIncorrectOrders_7_1_TEST to /Internal Reports' {
            $testreportpath = "$testprojectPath\$reportname.rdl"
            $originalvalue = "REP20162601502158049"

            Update-ValueInFile -file $testreportpath -currentvalue $batchidtoken -newvalue $originalvalue

            Write-Host "Uploading the report $testreportpath to $path"

            Write-ReportToRsServer -rsservername $rsservername -path $path -localpath $testreportpath -Description 'ThisIsATestProjectInstalledByScript-Original'
            
            Update-ValueInFile -file $testreportpath -currentvalue $originalvalue -newvalue $batchidtoken
            
        }

        It 'Should find ReportIncorrectOrders_7_1_TEST on the server under /Internal Reports' {
            Write-Host "Checking if we can find the report $reportname under $path"
            $rscontent = Get-FolderContentFromRs -rsservername $rsservername -path $path -reportname $reportname
            $rscontent.Count | Should Be 1
            $rscontent.Path | Should Be "$path/$reportname"
            $rscontent.Description | Should Be "ThisIsATestProjectInstalledByScript-Original"
        }

        It 'Should update the path to datasources for ReportIncorrectOrders_7_1_TEST' {
            $fullpath = "$path/$reportname"
            $pathtodatasources = "/Data Sources"
            
            Update-DataSourcesPathForReport -rsservername $rsservername -fullpath $fullpath -datasourcepath $pathtodatasources
        }

        It 'Should create a datadriven email subscription' {
            $toemail = "tonni.hult@seb.se"

            $subscriptionfile = "$testprojectPath\SUB_INCORRECT_ORDER.subscription.json"

            Update-ValueInFile -file $subscriptionfile -currentvalue $toemailadresstoken -newvalue $toemail
            
            $result = New-SubscriptionForReport -rsservername $rsservername -path $path -subscriptionfile $subscriptionfile
            write-output $result
            
            Update-ValueInFile -file $subscriptionfile -currentvalue $toemail -newvalue $toemailadresstoken
        }
    
        It 'Should create a datadriven fileshare subscription' {
            $subscriptionfile = "$testprojectPath\Sub_ReportIncorrectOrder.subscription.json"
            $fileshare = "\\\\B5481047\\exposed"

            Update-ValueInFile -file $subscriptionfile -currentvalue $filesharetoken -newvalue $fileshare
            
            $result = New-SubscriptionForReport -rsservername $rsservername -path $path -subscriptionfile $subscriptionfile
            write-output $result

            Update-ValueInFile -file $subscriptionfile -currentvalue $fileshare -newvalue $filesharetoken
        }        

        It 'Should upload any subreports' {
            $subreportfiles = Get-ChildItem -Path "$testprojectPath\" -Filter "*.rdl" -Exclude "$reportname.rdl" -Recurse
            $originalvalue = "REP20162601502158049"

            foreach ($subreportfile in $subreportfiles) {
                Update-ValueInFile -file $subreportfile.FullName -currentvalue $batchidtoken -newvalue $originalvalue
                Write-Host "Uploading the report $($subreportfile.FullName) to $path"
    
                Write-ReportToRsServer -rsservername $rsservername -path $path -localpath $subreportfile.FullName -Description 'AddingASubReportByScript-Original'
                
                Update-ValueInFile -file $subreportfile.FullName -currentvalue $originalvalue -newvalue $batchidtoken                
            }
        }

        It 'Should update the path to datasources for any subreports' {
            $subreportfiles = Get-ChildItem -Path "$testprojectPath\" -Filter "*.rdl" -Exclude "$reportname.rdl" -Recurse
            $pathtodatasources = "/Data Sources"
            
            foreach ($subreportfile in $subreportfiles) {                
                $subfullpath = "$path/$($subreportfile.BaseName)"    
                Write-Host "Setting datasource $pathtodatasources for $subfullpath"

                Update-DataSourcesPathForReport -rsservername $rsservername -fullpath $subfullpath -datasourcepath $pathtodatasources
            }
        }        
    }

    Context 'ReportIncorrectOrders_7_1_TEST has been updated and is reinstalled on the server' {
        It 'Should upload ReportIncorrectOrders_7_1_TEST to /Internal Reports and overwrite the current one' {
            $testreportpath = "$testprojectPath\$reportname.rdl"
            $updatedvalue = "REP20171001716188126"

            Update-ValueInFile -file $testreportpath -currentvalue $batchidtoken -newvalue $updatedvalue

            Write-Host "Uploading the report $testreportpath to $path with overwrite flag"
            Write-ReportToRsServer -rsservername $rsservername -path $path -localpath $testreportpath -Description 'ThisIsATestProjectInstalledByScript-Updated' -overwrite

            Update-ValueInFile -file $testreportpath -currentvalue $updatedvalue -newvalue $batchidtoken 
        }

        It 'Should update defaultvalues for ReportParameters' {
            $testreportpath = "$testprojectPath\$reportname.rdl"
            $updatedvalue = "REP20171001716188126"
            $fullpath = "$path/$reportname"
            Update-ValueInFile -file $testreportpath -currentvalue $batchidtoken -newvalue $updatedvalue

            Write-Host "Updating the defaultvalue for reportparameters in the report $testreportpath at $path"
            Update-ValuesForParameterInReport -rsservername $rsservername -fullpath $fullpath -localpath $testreportpath

            Update-ValueInFile -file $testreportpath -currentvalue $updatedvalue -newvalue $batchidtoken 
        }

        It 'Should find the updated report ReportIncorrectOrders_7_1_TEST under /Internal Reports' {
            Write-Host "Checking if we can find the updated report $reportname under $path"
            $rscontent = Get-FolderContentFromRs -rsservername $rsservername -path $path -reportname $reportname
            $rscontent.Count | Should Be 1
            $rscontent.Path | Should Be "$path/$reportname"
            $rscontent.Description | Should Be "ThisIsATestProjectInstalledByScript-Updated"
        }
    }

    Context 'ReportIncorrectOrders_7_1_TEST is to be removed from the server' {    
        It 'Should remove any subreports' {
            $subreportfiles = Get-ChildItem -Path "$testprojectPath\" -Filter "*.rdl" -Exclude "$reportname.rdl" -Recurse

            foreach ($file in $subreportfiles) {
                Remove-ReportFromRsServer -rsservername $rsservername -path $path -reportname $file.BaseName    
            }

        }

        It 'Should not find SubReportIncorrectOrders_TEST in /Internal Reports' {
            $subreportfiles = Get-ChildItem -Path "$testprojectPath\" -Filter "*.rdl" -Exclude "$reportname.rdl" -Recurse

            foreach ($file in $subreportfiles) {
                Write-Host "Checking if we can find the report $($file.BaseName) under $path"

                $rscontent = Get-FolderContentFromRs -rsservername $rsservername -path $path -reportname $file.BaseName
                $rscontent.Count | Should Be 0                
            }
        }

        It 'Should remove the test report' {
            Remove-ReportFromRsServer -rsservername $rsservername -path $path -reportname $reportname
        }

        It 'Should not find ReportIncorrectOrders_7_1_TEST in /Internal Reports' {
            Write-Host "Checking if we can find the report $reportname under $path"

            $rscontent = Get-FolderContentFromRs -rsservername $rsservername -path $path -reportname $reportname
            $rscontent.Count | Should Be 0
        }
    }
    Remove-Variable -Name "isrunningasatest" -Scope Global -Force
}

Describe 'Get subscription /Internal Reports/ReportIncorrectOrders_7_1' {
    $fullpath = "/Internal Reports/ReportIncorrectOrders_7_1"

    It 'Should get the subscriptions' {
        $result = Get-SubscriptionsForReport -rsservername $rsservername -path $fullpath
        Write-Output $result
        foreach ($item in $result) {
            #$item.Description | Should Be 'xxx'
            $item.Description | Should -BeIn @("SUB_INCORRECT_ORDER", "Sub_ReportIncorrectOrder_Mail")
        }
    }
}

Describe 'Get subscriptionfile ReportIncorrectOrders_7_1_TEST_Email_subscription.json' {
    $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject'

    It 'Should return an object' {
        $subscriptionfile = "$testprojectPath\SUB_INCORRECT_ORDER.subscription.json"
        $subscription = Get-Content $subscriptionfile | ConvertFrom-Json

        $subscription.Description | Should Be "SUB_INCORRECT_ORDER"
    }
}

Describe 'Insert fileshare subscription for ReportTAPaymentsToAndFromIMABFunds_7_1' {
    Set-Variable -Name "isrunningasatest" -Value $true -Scope Global
    $path = "/Internal Reports"
    $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject\SSRS\TEST_ReportIncorrectOrders'
    $reportname = 'ReportTAPaymentsToAndFromIMABFunds_7_1'
    
    It 'Should create a fileshare subscription with Dataset=>ValueDate' {
        $subscriptionfile = "$testprojectPath\Sub_Payments.subscription.json"

        $result = New-SubscriptionForReport -rsservername $rsservername -path $path -subscriptionfile $subscriptionfile
        write-output $result
    }
}

# Describe 'Set standard subscription for testreport ReportIncorrectOrders_7_1_TEST' {
#     $path = "/Internal Reports/ReportIncorrectOrders_7_1_TEST"
#     $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject'

#     It 'Should create a email subscription' {
#         $subscriptionfile = "$testprojectPath\SUB_INCORRECT_ORDER.subscription.json"
#         $result = New-SubscriptionForReport -rsservername $rsservername -path $path -subscriptionfile $subscriptionfile
#         write-output $result
#     }
# }

# Describe 'Set datadriven subscription for testreport ReportIncorrectOrders_7_1_TEST' {
#     $path = "/Internal Reports/ReportIncorrectOrders_7_1_TEST"
#     $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject'

#     It 'Should create a datadriven email subscription' {
#         $subscriptionfile = "$testprojectPath\SSRS\TEST_ReportIncorrectOrders\SUB_INCORRECT_ORDER.subscription.json"
#         $result = New-SubscriptionForReport -rsservername $rsservername -path $path -subscriptionfile $subscriptionfile
#         write-output $result
#     }

#     It 'Should create a datadriven fileshare subscription' {
#         $subscriptionfile = "$testprojectPath\SSRS\TEST_ReportIncorrectOrders\Sub_ReportIncorrectOrder.subscription.json"
#         $result = New-SubscriptionForReport -rsservername $rsservername -path $path -subscriptionfile $subscriptionfile
#         write-output $result
#     }
# }

# Use this when you need to get the report from the server
# Describe 'Getting data with out' {
#     $path = "/Internal Reports"
#     $reportname = "ReportIncorrectOrders_7_1_TEST"
#     It 'should get data' {
#         Out-RsCatalogItem -ReportServerUri http://wsp3068c.sebank.se/reportserver -Destination c:\exposed -RsItem "$path/$reportname"
#     }
# }


# This is used for separate delete of the testfile if we've not runned the full test with removal above
Describe 'Remove Reporting Service Item /Internal Reports/ReportIncorrectOrders_7_1_TEST' {
    $path = "/Internal Reports"
    $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject\SSRS\TEST_ReportIncorrectOrders'
    $reportname = 'ReportIncorrectOrders_7_1_TEST'

    Context 'ReportIncorrectOrders_7_1_TEST is installed on the server' {
        It 'Should find ReportIncorrectOrders_7_1_TEST in /Internal Reports' {
            Write-Host "Checking if we can find the report $reportname under $path"

            $rscontent = Get-FolderContentFromRs -rsservername $rsservername -path $path -reportname $reportname
            $rscontent.Count | Should Be 1
        }
    }

    Context 'ReportIncorrectOrders_7_1_TEST is to be removed from the server' {
        It 'Should remove any subreports' {
            $subreportfiles = Get-ChildItem -Path "$testprojectPath\" -Filter "*.rdl" -Exclude "$reportname.rdl" -Recurse

            foreach ($file in $subreportfiles) {
                Remove-ReportFromRsServer -rsservername $rsservername -path $path -reportname $file.BaseName
            }

        }

        It 'Should not find SubReportIncorrectOrders_TEST in /Internal Reports' {
            $subreportfiles = Get-ChildItem -Path "$testprojectPath\" -Filter "*.rdl" -Exclude "$reportname.rdl" -Recurse

            foreach ($file in $subreportfiles) {
                Write-Host "Checking if we can find the report $($file.BaseName) under $path"

                $rscontent = Get-FolderContentFromRs -rsservername $rsservername -path $path -reportname $file.BaseName
                $rscontent.Count | Should Be 0                
            }
        }

        It 'Should remove the test report' {
            Remove-ReportFromRsServer -rsservername $rsservername -path $path -reportname $reportname
        }

        It 'Should not find ReportIncorrectOrders_7_1_TEST in /Internal Reports' {
            Write-Host "Checking if we can find the report $reportname under $path"

            $rscontent = Get-FolderContentFromRs -rsservername $rsservername -path $path -reportname $reportname
            $rscontent.Count | Should Be 0
        }
    }
}

Describe 'Removing all installed test reports' {
    $path = "/Internal Reports"
    $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject\SSRS\TEST_ReportIncorrectOrders'

    It 'Should remove all installed reports based on files in the local folder' {
        Remove-ReportsFromRsServer -rsservername $rsservername -path $path -localpath $testprojectPath
    }
}

Describe 'Handle installation of report ExternalFundOrder_6_1_TEST' {
    Set-Variable -Name "isrunningasatest" -Value $true -Scope Global
    $path = "/Internal Reports"
    $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject\SSRS\TEST_ReportIncorrectOrders'
    $reportname = 'ExternalFundOrder_6_1_TEST'

    Context 'ExternalFundOrder_6_1_TEST is getting installed' {
        It 'Should upload ExternalFundOrder_6_1_TEST to /Internal Reports' {
            $testreportpath = "$testprojectPath\$reportname.rdl"

            Write-Host "Uploading the report $testreportpath to $path"

            Write-ReportToRsServer -rsservername $rsservername -path $path -localpath $testreportpath -Description 'ThisIsATestProjectInstalledByScript-Original'            
        }
    }

    Context 'ExternalFundOrder_6_1_TEST has been changed and is reinstalled' {
        It 'Should upload ExternalFundOrder_6_1_TEST to /Internal Reports and overwrite the current one' {
            $testreportpath = "$testprojectPath\$reportname.rdl"

            Write-Host "Uploading the report $testreportpath to $path with overwrite flag"
            Write-ReportToRsServer -rsservername $rsservername -path $path -localpath $testreportpath -Description 'ThisIsATestProjectInstalledByScript-Updated' -overwrite
        }
    }
}

# Describe 'variable' {
#     It 'not exist' {
#         $result = Test-Path variable:global:existsnot
#         $result | Should be $false
#     }

#     It 'exists' {
#         Set-Variable -Name "itexists" -Value $true -Scope Global
#         $result = Test-Path variable:global:itexists
#         $result | Should Be $true
#         $exists = Get-Variable -Name "itexists" -Scope Global -ValueOnly
#         $exists | Should Be $true
#         Remove-Variable -Name "itexists" -Scope Global -Force
#     }
# }