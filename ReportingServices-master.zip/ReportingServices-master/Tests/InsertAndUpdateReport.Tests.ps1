. "$PSScriptRoot\..\src\ReportingServicesReport.ps1"
Import-Module "$PSScriptRoot\..\src\ReportingServicesTools\0.0.4.7\ReportingServicesTools.psd1"

function Update-ValueInFile {
    param(
        [string]$file,
        [string]$currentvalue,
        [string]$newvalue
    )
    
    $content = Get-Content -Path $file

    $updated = $content.Replace($currentvalue, $newvalue)

    Set-Content -Path $file -Value $updated
}

$rsservername = "wsp3068c" # New SSRS 2016 server

# Run a complete installation through InsertAndUpdateReport and then remove test report
Describe 'Install Reporting Service Item /Internal Reports/ReportIncorrectOrders_7_1_TEST' {
    Set-Variable -Name "isrunningasatest" -Value $true -Scope Global
    $path = "/Internal Reports"
    $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject\SSRS\TEST_ReportIncorrectOrders'
    $reportname = 'ReportIncorrectOrders_7_1_TEST'
    $batchidtoken = "#{BATCHIDTOKEN}#"
    $toemailadresstoken = "#{EMAILTOADRESSTOKEN}#"
    $filesharetoken = "#{FILESHARETOKEN}#"

    Context 'ReportIncorrectOrders_7_1_TEST is not installed on the server' {
        It 'Should not find ReportIncorrectOrders_7_1_TEST in /Internal Reports' {
            Write-Host "Checking if we can find the report $reportname under $path"

            $rscontent = Get-FolderContentFromRs -rsservername $rsservername -path $path -reportname $reportname
            $rscontent.Count | Should Be 0
        }
    }

    Context 'ReportIncorrectOrders_7_1_TEST is getting installed on the server' {
        It 'Should upload ReportIncorrectOrders_7_1_TEST to /Internal Reports' {
            $testreportpath = "$testprojectPath\$reportname.rdl"
            $emailsubscriptionpath = "$testprojectPath\SUB_INCORRECT_ORDER.subscription.json"
            $filesharesubscriptionpath = "$testprojectPath\Sub_ReportIncorrectOrder.subscription.json"
            $originalvalue = "REP20162601502158049"
            $toemail = "tonni.hult@seb.se"
            $fileshare = "\\\\B5481047\\exposed"

            Update-ValueInFile -file $testreportpath -currentvalue $batchidtoken -newvalue $originalvalue
            Update-ValueInFile -file $emailsubscriptionpath -currentvalue $toemailadresstoken -newvalue $toemail
            Update-ValueInFile -file $filesharesubscriptionpath -currentvalue $filesharetoken -newvalue $fileshare

            Write-Host "Uploading the report $testreportpath to $path"

            . "$PSScriptRoot\..\src\InsertAndUpdateReport.ps1" -MainReportName $reportname -ReportFolder "Internal Reports" -ReportSourceFolderPath $testprojectPath -DataSourcesFolder "Data Sources" -ReportingServer $rsservername -Description 'ThisIsATestProjectInstalledByInsertAndUpdateReportScript-Original'
            #Write-ReportToRsServer -rsservername $rsservername -path $path -localpath $testreportpath -Description 'ThisIsATestProjectInstalledByScript-Original'
            
            Update-ValueInFile -file $testreportpath -currentvalue $originalvalue -newvalue $batchidtoken
            Update-ValueInFile -file $emailsubscriptionpath -currentvalue $toemail -newvalue $toemailadresstoken
            Update-ValueInFile -file $filesharesubscriptionpath -currentvalue $fileshare -newvalue $filesharetoken
        }

        It 'Should find ReportIncorrectOrders_7_1_TEST on the server under /Internal Reports' {
            Write-Host "Checking if we can find the report $reportname under $path"
            $rscontent = Get-FolderContentFromRs -rsservername $rsservername -path $path -reportname $reportname
            $rscontent.Count | Should Be 1
            $rscontent.Path | Should Be "$path/$reportname"
            $rscontent.Description | Should Be "ThisIsATestProjectInstalledByInsertAndUpdateReportScript-Original"
        }
    }

    Context 'ReportIncorrectOrders_7_1_TEST is getting updated on the server' {
        It 'Should update ReportIncorrectOrders_7_1_TEST to /Internal Reports' {
            $testreportpath = "$testprojectPath\$reportname.rdl"
            $emailsubscriptionpath = "$testprojectPath\SUB_INCORRECT_ORDER.subscription.json"
            $filesharesubscriptionpath = "$testprojectPath\Sub_ReportIncorrectOrder.subscription.json"
            # $newvalue = "REP2018001100011"
            $newvalue = "REP20171001716188126"
            $toemail = "tonni.hult@seb.se"
            $fileshare = "\\\\B5481047\\exposed"

            Update-ValueInFile -file $testreportpath -currentvalue $batchidtoken -newvalue $newvalue
            Update-ValueInFile -file $emailsubscriptionpath -currentvalue $toemailadresstoken -newvalue $toemail
            Update-ValueInFile -file $filesharesubscriptionpath -currentvalue $filesharetoken -newvalue $fileshare
            
            Write-Host "Updating the report $testreportpath to $path"

            . "$PSScriptRoot\..\src\InsertAndUpdateReport.ps1" -MainReportName $reportname -ReportFolder "Internal Reports" -ReportSourceFolderPath $testprojectPath -DataSourcesFolder "Data Sources" -ReportingServer $rsservername -Description 'ThisIsATestProjectInstalledByInsertAndUpdateReportScript-Updated'
            
            Update-ValueInFile -file $testreportpath -currentvalue $newvalue -newvalue $batchidtoken          
            Update-ValueInFile -file $emailsubscriptionpath -currentvalue $toemail -newvalue $toemailadresstoken  
            Update-ValueInFile -file $filesharesubscriptionpath -currentvalue $fileshare -newvalue $filesharetoken
        }

        It 'Should find an updated ReportIncorrectOrders_7_1_TEST on the server under /Internal Reports' {
            Write-Host "Checking if we can find the report $reportname under $path"
            $rscontent = Get-FolderContentFromRs -rsservername $rsservername -path $path -reportname $reportname
            $rscontent.Count | Should Be 1
            $rscontent.Path | Should Be "$path/$reportname"
            $rscontent.Description | Should Be "ThisIsATestProjectInstalledByInsertAndUpdateReportScript-Updated"
        }        

        # It 'Should not find SubReportIncorrectOrders_TEST in /Internal Reports' {
        #     # $subreportfiles = Get-ChildItem -Path "$testprojectPath\" -Filter "SubReportIncorrectOrders_TEST.rdl" -Exclude "$reportname.rdl" -Recurse

        #     # foreach ($file in $subreportfiles) {
        #         Write-Host "Checking if we can find the report SubReportIncorrectOrders_TEST under $path"

        #         $rscontent = Get-FolderContentFromRs -rsservername $rsservername -path $path -reportname "SubReportIncorrectOrders_TEST"
        #         $rscontent.Count | Should Be 0                
        #     # }
        # }        
    }

    Context 'ReportIncorrectOrders_7_1_TEST is to be removed from the server' {
        It 'Should remove any subreports' {
            $subreportfiles = Get-ChildItem -Path "$testprojectPath\" -Filter "*.rdl" -Exclude "$reportname.rdl","subReportIncorrectOrders_TEST.rdl" -Recurse

            foreach ($file in $subreportfiles) {
                Remove-ReportFromRsServer -rsservername $rsservername -path $path -reportname $file.BaseName           
            }
        }

        It 'Should remove the test report' {
            Remove-ReportFromRsServer -rsservername $rsservername -path $path -reportname $reportname
        }

        It 'Should not find ReportIncorrectOrders_7_1_TEST in /Internal Reports' {
            Write-Host "Checking if we can find the report $reportname under $path"

            $rscontent = Get-FolderContentFromRs -rsservername $rsservername -path $path -reportname $reportname
            $rscontent.Count | Should Be 0
        }
    }    

    Remove-Variable -Name "isrunningasatest" -Scope Global -Force
}

Describe 'Handle installation of report ExternalFundOrder_6_1_TEST' {
    Set-Variable -Name "isrunningasatest" -Value $true -Scope Global
    $path = "/Internal Reports"
    $testprojectPath = (Get-Item -Path ".\").FullName  + '\Testproject\SSRS\TEST_ReportIncorrectOrders'
    $reportname = 'ExternalFundOrder_6_1_TEST'

    Context 'ExternalFundOrder_6_1_TEST is getting installed' {
        It 'Should upload ExternalFundOrder_6_1_TEST to /Internal Reports' {
            $testreportpath = "$testprojectPath\$reportname.rdl"

            Write-Host "Uploading the report $testreportpath to $path"
            . "$PSScriptRoot\..\src\InsertAndUpdateReport.ps1" -MainReportName $reportname -ReportFolder "Internal Reports" -ReportSourceFolderPath $testprojectPath -DataSourcesFolder "Data Sources" -ReportingServer $rsservername -Description 'ThisIsATestProjectInstalledByInsertAndUpdateReportScript-Original'
            # Write-ReportToRsServer -rsservername $rsservername -path $path -localpath $testreportpath -Description 'ThisIsATestProjectInstalledByScript-Original'            
        }
    }

    Context 'ExternalFundOrder_6_1_TEST has been changed and is reinstalled' {
        It 'Should upload ExternalFundOrder_6_1_TEST to /Internal Reports and overwrite the current one' {
            $testreportpath = "$testprojectPath\$reportname.rdl"

            Write-Host "Uploading the report $testreportpath to $path with overwrite flag"
            . "$PSScriptRoot\..\src\InsertAndUpdateReport.ps1" -MainReportName $reportname -ReportFolder "Internal Reports" -ReportSourceFolderPath $testprojectPath -DataSourcesFolder "Data Sources" -ReportingServer $rsservername -Description 'ThisIsATestProjectInstalledByInsertAndUpdateReportScript-Updated'
            # Write-ReportToRsServer -rsservername $rsservername -path $path -localpath $testreportpath -Description 'ThisIsATestProjectInstalledByScript-Updated' -overwrite
        }
    }
}