
param(
    [string] $ReportName,
    [string] $ReportFolder,
    [string] $ReportingServer
)

Write-Host "Starting up reporting services controller file"

## Fetch the variables

Write-host "********** Variables ***********"

Write-Host "Report: $ReportName"
Write-Host "Report folder in reporting services: $ReportFolder"
Write-Host "Server to remove from on: $ReportingServer"

Write-host "*********************"


. "$PSScriptRoot\ReportingServicesReport.ps1"
Import-Module "$PSScriptRoot\ReportingServicesTools\0.0.4.7\ReportingServicesTools.psd1"

# $path = "/Internal Reports"
# $reportname = 'ReportIncorrectOrders_7_1_TEST'

$ReportFolder = Get-NormalizedRsFolderPath -path $ReportFolder
$fullpath = "$ReportFolder/$ReportName"

$url = Get-RsServerPath -rsservername $ReportingServer
Remove-RsCatalogItem -ReportServerUri $url -RsItem $fullpath -Confirm:$false

Write-Host "Confirming that the report $ReportName is removed from $ReportFolder on server $ReportingServer"

$rscontent = Get-FolderContentFromRs -rsservername $ReportingServer -path $ReportFolder -reportname $ReportName

if($rscontent.Count -ne 0) {
    Write-Error "Report $ReportName did not get removed from $ReportFolder on server $ReportingServer"
}