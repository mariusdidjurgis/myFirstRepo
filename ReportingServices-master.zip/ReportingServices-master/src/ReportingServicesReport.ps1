function Get-RsServerPath {
    param (
        [string] $rsservername,
        [switch] $version2005, 
        [switch] $fullwsdl
    )

    if($fullwsdl.IsPresent -and $version2005.IsPresent) {
        return "http://$rsservername/ReportServer/ReportService2005.asmx?WSDL"
    }
    elseif ($fullwsdl.IsPresent) {
        return "http://$rsservername/ReportServer/ReportService2010.asmx?WSDL"
    }
    else {
        return "http://$rsservername.sebank.se/reportserver"
    }
}

function Get-NormalizedRsFolderPath {
    param (
        [string] $path
    )

    $normalized = $path

    if (!($path.StartsWith("/"))) {
        $normalized = "/$path"
    }

    return $normalized
}

# Get all reports or a selected report from a specific folder
function Get-FolderContentFromRs {
    param (
        [string] $rsservername,
        [string] $path,
        [string] $reportname
    )

    $path = Get-NormalizedRsFolderPath $path
    $url = Get-RsServerPath -rsservername $rsservername

    if([string]::IsNullOrEmpty($reportname)) {
        get-rsfoldercontent -ReportServerUri $url -path $path
    }
    else {
        get-rsfoldercontent -ReportServerUri $url -path $path | Where-Object Name -EQ $reportname
    }
}

function Get-DataSourcesFromReport {
    param (
        [string] $rsservername,
        [string] $fullpath
    )

    $fullpath = Get-NormalizedRsFolderPath $fullpath
    $url = Get-RsServerPath -rsservername $rsservername

    Get-RsItemDataSource -ReportServerUri $url -Path $fullpath 
}

function Update-DataSourcesPathForReport {
    param (
        [string] $rsservername,
        [string] $fullpath,        
        [string] $datasourcepath
    )

    if([string]::IsNullOrEmpty($datasourcepath)) {
        Write-FormattedOutput -text "No datasource path was set, using default /Data Sources" -severity warning
        $datasourcepath = "/Data Sources"
    }

    $datasourcepath = Get-NormalizedRsFolderPath $datasourcepath
    $fullpath = Get-NormalizedRsFolderPath $fullpath
    $url = Get-RsServerPath -rsservername $rsservername
    $datasources = Get-DataSourcesFromReport -rsservername $rsservername -fullpath $fullpath

    for ($i = 0; $i -lt $datasources.Count; $i++) {
        # A new report does not have this set = $null
        # If a report is updated we need to check wheather we need to update datasourcepath or not
        $currentpath = $datasources[$i].Item.Reference
        $updatedpath = ""

        if ($null -eq $currentpath) {
            $updatedpath = $datasourcepath + "/" + $datasources[$i].Name
        } elseif(!($currentpath.StartsWith($datasourcepath))) {
            $updatedpath = $datasourcepath + "/" + $currentpath
        }
        else {
            # No change, exit function
            return
        }    
        
        Set-RsDataSourceReference -ReportServerUri $url -Path $fullpath -DataSourceName $datasources[$i].Name -DataSourcePath $updatedpath
    }
}

function Write-ReportToRsServer {
    param (
        [string] $rsservername,
        [string] $path,
        [string] $localpath,
        [string] $description,
        [switch] $overwrite
    )
    $path = Get-NormalizedRsFolderPath $path
    $url = Get-RsServerPath -rsservername $rsservername

    if($overwrite.IsPresent) {
        Write-RsCatalogItem -Path $localpath -RsFolder $path -Description $description -ReportServerUri $url -Overwrite -Verbose
    }
    else {
        Write-RsCatalogItem -Path $localpath -RsFolder $path -Description $description -ReportServerUri $url -Verbose
    }
}

function Remove-ReportFromRsServer {
    param (
        [string] $rsservername,
        [string] $path,
        [string] $reportname
    )

    $path = Get-NormalizedRsFolderPath $path
    $url = Get-RsServerPath -rsservername $rsservername

    $fullpath = "$path/$reportname"

    $rscontent = Get-FolderContentFromRs -rsservername $rsservername -path $path -reportname $reportname
    
    if($rscontent.Count -eq 0) {
        Write-FormattedOutput -text "The report $reportname was not found under $path on $url. No report to delete" -severity warning
        return
    }

    Remove-RsCatalogItem -ReportServerUri $url -RsItem $fullpath -Confirm:$false
}

# Used for cleanup if a first installation of a report goes bad. Then it is used to cleanup all installed reports
function Remove-ReportsFromRsServer {
    param(
        [string] $rsservername,
        [string] $path,
        [string] $localpath
    )

    if(!(Test-Path -Path $localpath)) {
        Write-FormattedOutput -text "The path $localpath was not found. No reports can be removed" -severity warning
        return
    }

    $reportfiles = Get-ChildItem -Path $localpath -Filter "*.rdl"

    foreach ($reportfile in $reportfiles) {
        $file = Get-Item $reportfile.FullName
        $reportname = $file.BaseName
        
        Remove-ReportFromRsServer -rsservername $rsservername -path $path -reportname $reportname
    }
}

function Get-SubscriptionsForReport {
    param (
        [string] $rsservername,
        [string] $fullpath
    )

    $fullpath = Get-NormalizedRsFolderPath $fullpath
    $url = Get-RsServerPath -rsservername $rsservername

    Get-RsSubscription -ReportServerUri $url -RsItem $fullpath
}

function IsReportInstalled {
    param (
        [string] $rsservername,
        [string] $path,
        [string] $reportname
    ) 
    
    $result = Get-FolderContentFromRs -rsservername $rsservername -path $path -reportname $reportname

    if($result.Count -eq 0) {
        return $false
    }

    return $true
}

function Remove-SubscriptionsForReport {
    param (
        [string] $rsservername,
        [string] $fullpath
    )

    $url = Get-RsServerPath -rsservername $rsservername

    Get-SubscriptionsForReport -rsservername $rsservername -fullpath $fullpath | 
    Remove-RsSubscription -ReportServerUri $url -Confirm:$false
}

function New-SubscriptionForReport {
    param (
        [string] $rsservername,
        [string] $path,
        [string] $subscriptionfile
    )

    if(!(Test-Path $subscriptionfile)) {
        Write-FormattedOutput -text "The file $subscriptionfile was not found. Cannot create a subscription, exiting function New-SubscriptionForReport" -severity warning
        return
    }

    $subscription = Get-Content $subscriptionfile | ConvertFrom-Json
    $report = $subscription.Report

    $pathtoreport = "$path/$report" 

    # We basically only support DataDriven subscriptions as this is what is normally used
    if($subscription.DataDriven -eq $true) {
        New-DataDrivenSubscriptionForReport -rsservername $rsservername -fullpath $pathtoreport -subscriptionfile $subscriptionfile
    } else {
        New-StandardSubscriptionForReport -rsservername $rsservername -fullpath $pathtoreport -subscriptionfile $subscriptionfile
    }
}

# This is normally not used and not fully supported. Needs improvement
function New-StandardSubscriptionForReport {
    param (
        [string] $rsservername,
        [string] $fullpath,
        [string] $subscriptionfile
    )

    if(!(Test-Path $subscriptionfile)) {
        Write-FormattedOutput -text "The file $subscriptionfile was not found. Cannot create a subscription, exiting function New-StandardSubscriptionForReport" -severity warning
    }

    $fullpath = Get-NormalizedRsFolderPath $fullpath
    $url = Get-RsServerPath -rsservername $rsservername

    $subscription = Get-Content $subscriptionfile | ConvertFrom-Json
    $schedulexml = Get-ScheduleXmlForReport -subscriptionfile $subscriptionfile

    switch ($subscription.DeliveryMethod) {
        Email { 
            $IncludeLink = [System.Convert]::ToBoolean($subscription.Email.IncludeLink)
            $IncludeReport = [System.Convert]::ToBoolean($subscription.Email.IncludeReport)

            New-RsSubscription -ReportServerUri $url -RsItem $path -Description $subscription.Description -DeliveryMethod $subscription.DeliveryMethod `
                -EventType $subscription.EventType -RenderFormat $subscription.Email.RenderFormat -To $subscription.Email.To -CC $subscription.Email.Cc `
                -BCC $subscription.Email.Bcc -ReplyTo $subscription.Email.ReplyTo -Subject $subscription.Email.Subject -Priority $subscription.Email.Priority `
                -Comment $subscription.Email.Comment -Schedule $schedulexml -ExcludeLink:(-not $IncludeLink) -ExcludeReport:(-not $IncludeReport)
        }
        FileShare {

        }
        Default {throw [System.Exception] "DeliveryMethod should be Email or FileShare"}
    }
}

# Creates necessary xml for the schedule. Might need more testing to see that all alternatives are set properly
function Get-ScheduleXmlForReport {
    param (
        [string] $subscriptionfile
    )

    if(!(Test-Path $subscriptionfile)) {
        Write-FormattedOutput -text "The file $subscriptionfile was not found. Cannot create a subscription, exiting function Get-ScheduleXmlForReport" -severity warning
    }

    $subscription = Get-Content $subscriptionfile | ConvertFrom-Json

    $scheduleparams = @{}

    switch ($subscription.Schedule.Recurrence) {
        Minute {            
            $scheduleparams.Minute = $true
            $scheduleparams.Interval = $subscription.Schedule.Interval
        }
        Daily {       
            $scheduleparams.Daily = $true
            $scheduleparams.Interval = $subscription.Schedule.Interval        
        }
        Weekly {
            $scheduleparams.Weekly = $true
            $scheduleparams.Interval = $subscription.Schedule.Interval

            if(!([string]::IsNullOrEmpty($subscription.Schedule.DaysOfWeek))){                
                $scheduleparams.DaysOfWeek = $subscription.Schedule.DaysOfWeek                
            }
        }
        Monthly {
            $scheduleparams.Monthly = $true
            $scheduleparams.DaysOfMonths = $subscription.Schedule.DaysOfMonths

            if(!([string]::IsNullOrEmpty($subscription.Schedule.Months))){      
                $scheduleparams.Months = $subscription.Schedule.Months                              
            }                     
        }
        MonthlyDayOfWeek {
            $scheduleparams.MonthlyDayOfWeek = $true
            $scheduleparams.WeekOfMonth = $subscription.Schedule.WeekOfMonth

            if(!([string]::IsNullOrEmpty($subscription.Schedule.Months))){      
                $scheduleparams.Months = $subscription.Schedule.Months                              
            }        
            
            if(!([string]::IsNullOrEmpty($subscription.Schedule.DaysOfWeek))){                
                $scheduleparams.DaysOfWeek = $subscription.Schedule.DaysOfWeek                
            }
        }
        Once {            
            $scheduleparams.Once = $true
        }
        Default {
            Write-FormattedOutput "Recurrence $($subscription.Schedule.Recurrence) is not supported, should be Minute, Daily, Weekly, Monthly, MonthlyDayOfWeek or Once" -severity error
            throw [System.Exception] "Recurrence $($subscription.Schedule.Recurrence) is not supported, should be Minute, Daily, Weekly, Monthly, MonthlyDayOfWeek or Once"
        }
    }

    if(!([string]::IsNullOrEmpty($subscription.Schedule.Start))) {
        $scheduleparams.Start = $subscription.Schedule.Start
    }

    if(!([string]::IsNullOrEmpty($subscription.Schedule.End))) {
        $scheduleparams.End = $subscription.Schedule.End
    }

    New-RsScheduleXml @scheduleparams
}

function New-DataDrivenSubscriptionForReport
{  
    param(
        [string] $rsservername,
        [string] $fullpath,
        [string] $subscriptionfile
    )

    Begin
    {
        if(!(Test-Path $subscriptionfile)) {
            Write-FormattedOutput -text "The file $subscriptionfile was not found. Cannot create a subscription, exiting function New-DataDrivenSubscriptionForReport" -severity warning
        }

        $fullpath = Get-NormalizedRsFolderPath $fullpath
        $url = Get-RsServerPath -rsservername $rsservername -fullwsdl

        $proxy = New-WebServiceProxy -Uri $url -UseDefaultCredential -ErrorAction Stop
    }
    Process
    { 
        $subscription = Get-Content $subscriptionfile | ConvertFrom-Json
        $schedulexml = Get-ScheduleXmlForReport -subscriptionfile $subscriptionfile

        $Namespace = $Proxy.GetType().NameSpace

        #https://docs.microsoft.com/en-us/sql/reporting-services/report-server-web-service/net-framework/reporting-services-delivery-extension-settings?view=sql-server-2017
        # TODO: We only support 2 delivery methods at the moment so we need to add more here further on
        switch ($subscription.DeliveryMethod) {
            Email { 
                # $IncludeLink = [System.Convert]::ToBoolean($subscription.Email.IncludeLink)
                # $IncludeReport = [System.Convert]::ToBoolean($subscription.Email.IncludeReport)

                $Params = @{
                    TO = $subscription.Email.To
                    CC = $subscription.Email.Cc
                    BCC = $subscription.Email.Bcc
                    ReplyTo = $subscription.Email.ReplyTo
                    IncludeReport = [System.Convert]::ToBoolean($subscription.Email.IncludeReport)
                    IncludeLink = [System.Convert]::ToBoolean($subscription.Email.IncludeLink)
                    Subject = $subscription.Email.Subject
                    Comment = $subscription.Email.Comment
                    RenderFormat = $subscription.Email.RenderFormat
                    Priority = $subscription.Email.Priority
                }
            }

            FileShare {
                $Params = @{
                    PATH = $subscription.FileShare.Path
                    FILENAME = $subscription.FileShare.Filename
                    FILEEXTN = $subscription.FileShare.Fileextension
                    RENDER_FORMAT = $subscription.FileShare.RenderFormat                 
                    WRITEMODE = $subscription.FileShare.Writemode
                    USERNAME = $subscription.FileShare.Username
                    DEFAULTCREDENTIALS = $false             
                }

                if([string]::IsNullOrEmpty($Params.USERNAME)){
                    $Params.DEFAULTCREDENTIALS = $true
                }

                # example found at https://github.com/Microsoft/ReportingServicesTools/blob/master/ReportingServicesTools/Functions/CatalogItems/Get-RsSubscription.ps1
                #         if ($FileShareCredentials -ne $null)
                #         {
                #             $Params.USERNAME = $FileShareCredentials.UserName
                #             $Params.PASSWORD = $FileShareCredentials.GetNetworkCredential().Password
                #             $Params.DEFAULTCREDENTIALS = $false
                #         }
                #         else
                #         {
                #             $Params.DEFAULTCREDENTIALS = $true
                #         }
            }

            Default {
                Write-FormattedOutput -text "DeliveryMethod should be Email or FileShare" -severity error
                throw [System.Exception] "DeliveryMethod should be Email or FileShare"
            }
        }

        try
        {
            $ParameterValues = @()
            $Params.GetEnumerator() | ForEach-Object {
                if(!([string]::IsNullOrEmpty($_.Value))) {
                    if($_.Value.ToString().StartsWith("DATASET=>")) {
                        $fieldalias = $_.Value.ToString().Substring(9)
                        $ParameterValues = $ParameterValues + (New-Object "$Namespace.ParameterFieldReference" -Property @{ ParameterName = $_.Name; FieldAlias = $fieldalias })                        
                    } else {
                        $ParameterValues = $ParameterValues + (New-Object "$Namespace.ParameterValue" -Property @{ Name = $_.Name; Value = $_.Value })
                    }
                }
            }

            $ExtensionSettings = New-Object "$Namespace.ExtensionSettings" -Property @{ Extension = "Report Server $($subscription.DeliveryMethod)"; ParameterValues = $ParameterValues }

            $datasourcereference = New-Object "$Namespace.DataSourceReference" -Property @{ Reference = $subscription.DataRetrievalPlan.Item.Reference}
            
            $FieldValues = @()
            foreach ($field in $subscription.DataRetrievalPlan.DataSet.Fields) {
                $FieldValues = $FieldValues + (New-Object "$Namespace.Field" -Property @{ Alias = $field.Alias; Name = $field.Name })
            }
            
            $QueryDefinition = New-Object "$Namespace.QueryDefinition" -Property @{ CommandText = $subscription.DataRetrievalPlan.DataSet.Query.CommandText; `
                CommandType = $subscription.DataRetrievalPlan.DataSet.Query.CommandType; Timeout = $subscription.DataRetrievalPlan.DataSet.Query.Timeout; `
                TimeoutSpecified = $subscription.DataRetrievalPlan.DataSet.Query.TimeoutSpecified }

            $DataSetDefinition = New-Object "$Namespace.DataSetDefinition" -Property @{ Fields = $FieldValues; Query = $QueryDefinition }

            $DataRetrievalPlan = New-Object "$Namespace.DataRetrievalPlan" -Property @{ DataSet = $DataSetDefinition; Item = $datasourcereference }

            $ReportParameters = Get-ParameterObjectArrayFromJson -parametersjson $subscription.Parameters -namespace $Namespace

            Write-FormattedOutput -text "Creating Subscription $($subscription.Description) for the report $fullpath..."
            $subscriptionId = $proxy.CreateDataDrivenSubscription($fullpath, $ExtensionSettings, $DataRetrievalPlan, $subscription.Description, $subscription.EventType, $schedulexml, $ReportParameters)

            Write-FormattedOutput -text "Subscription created successfully! Generated subscriptionId: $subscriptionId"
        }
        catch
        {
            Write-FormattedOutput "Exception occurred while creating subscription!: $($_.Exception.Message)" -severity error
            throw (New-Object System.Exception("Exception occurred while creating subscription! $($_.Exception.Message)", $_.Exception))
        }
    }
}

# Create array with the correct namespace and fields for all parameters
function Get-ParameterObjectArrayFromJson {
    param(
        [object]$parametersjson,
        [string]$namespace
    )

    $parametersobj = @()
    foreach ($parameter in $parametersjson) {
        if ($parameter.psobject.Properties.name[0] -eq 'ParameterName') {
            $parametersobj = $parametersobj + (New-Object "$namespace.ParameterFieldReference" -Property @{ FieldAlias = $parameter.FieldAlias; ParameterName = $parameter.ParameterName })    
        } else {
            $parametersobj = $parametersobj + (New-Object "$namespace.ParameterValue" -Property @{ Label = $parameter.Label; Name = $parameter.Name; Value = $parameter.Value })    
        }
    }

    return $parametersobj
}

# Updating those variables that are found to have default values. 
# These will not be updated during the redeploy of the report and need to be updated separately 
function Update-ValuesForParameterInReport {
    param (
        [string] $rsservername,
        [string] $fullpath,
        [string] $localpath
    )
    
    if(!(Test-Path $localpath)) {
        Write-FormattedOutput -text "The file $localpath was not found. Cannot update defaultvalues, exiting Update-ValuesForParameterInReport" -severity warning
    }

    [xml]$reportxml = Get-Content $localpath 

    if($null -ne $reportxml.Report.ReportParameters) {
        foreach($element in $reportxml.Report.ReportParameters.ReportParameter){
            $name = $element.Name

            # We only want to update parameters with default values
            # If there is no <prompt> element the visibility is Internal which here means that it is readonly
            if (($null -ne $element.DefaultValue) -and ($null -ne $element.DefaultValue.Values) -and ($null -ne $element.Prompt)) {
                Write-FormattedOutput -text "ReportParameter $name is found to have defaultvalues and has the prompt element set"
                $values = New-Object System.Collections.ArrayList
                foreach ($defaultvalue in $element.DefaultValue.Values.Value) {
                    $values.Add($defaultvalue)
                }

                Set-ValueForParameterWithDefaultValueInReport -rsservername $rsservername -fullpath $fullpath -parameter $name -value $values
            }
        }
    }
}

# Updating a report parameter that has default values and is not set to readonly 
function Set-ValueForParameterWithDefaultValueInReport {
    param(
        [string] $rsservername,
        [string] $fullpath,
        [string] $parameter,
        [string[]] $values
    )
    $url = Get-RsServerPath -rsservername $rsservername -version2005 -fullwsdl
    $fullpath = Get-NormalizedRsFolderPath $fullpath
    $proxy = New-WebServiceProxy -Uri $url -UseDefaultCredential -ErrorAction Stop

    $forrendering = $true
    
    # Because PS can return a empty string instead of null we create our own type and override ToString()

    $b = @"
    using System;
    namespace PsNullString
    {
    public class NullString
    {
        public override string ToString() { return null;}
    }
    }
"@

    add-type $b
    $psnull = New-Object PsNullString.NullString

    $namespace = $proxy.GetType().NameSpace
    $getreportparameter = New-Object "$namespace.ParameterValue" -Property @{ Name = $parameter}
    
    $installedparameters = $proxy.GetReportParameters($fullpath, $psnull, $forrendering, $getreportparameter, $null)

    $paramtoupdate = $installedparameters | Where-Object { $_.Name -eq $parameter}
    
    # We can only update the parameters of type string at the moment. 
    if(($null -ne $paramtoupdate) -and ($null -ne $paramtoupdate.Type) -and ($paramtoupdate.Type -eq "String")) {
        Write-FormattedOutput -text "Will update defaultvalues for reportparameter $parameter on report $fullpath using $url"
        $paramtoupdate.DefaultValues = $values
        
        $proxy.SetReportParameters($fullpath, $paramtoupdate)           
    }
    else {
        Write-FormattedOutput -text "Parameter $parameter was not a string and will not be updated" -severity warning
    }
}

function Write-FormattedOutput{
    param(
        [string]$text,
        [ValidateSet('info','warning', 'error')]
        [string]$severity = "info"
    )

    $outputtext = "$text"
    $isrunningasatest = Test-Path variable:global:isrunningasatest

    if($isrunningasatest) {
        $outputtext = "TESTRUN - $(Get-Date -Format o): $text"
    }

    switch ($severity) {
        'info' { 
            if($isrunningasatest) {
                Write-Host "$outputtext" 
            }
            else {
                Write-Verbose "$outputtext" 
            }
        }
        'warning' { Write-Warning "$outputtext" }
        'error' { Write-Error "$outputtext" }
        Default {Write-Error "This should not happen, text is $text and severity is $severity"}
    }
}