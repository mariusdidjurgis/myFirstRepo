
param(
    [string] $MainReportName,
    [string] $ReportFolder,
    [string] $ReportSourceFolderPath,
    [string] $DataSourcesFolder,
    [string] $ReportingServer,
    [string] $Description
)

. "$PSScriptRoot\ReportingServicesReport.ps1"
Import-Module "$PSScriptRoot\ReportingServicesTools\0.0.4.7\ReportingServicesTools.psd1"

Write-FormattedOutput -text "Starting up reporting services InsertAndUpdateReport file"

## Setup and show the variables
$reportfileending = ".rdl"
$subscriptionfilefilter = "*.subscription.json"
$deletefileending = ".delete"

if([string]::IsNullOrEmpty($MainReportName)){
    Write-FormattedOutput -text "MainReportName is empty, assuming that the foldername is to be used instead"
    $MainReportName = $ReportSourceFolderPath.Substring($ReportSourceFolderPath.LastIndexOf("\") +1)
}
# Set ,1 to be case insensitive
if(!($MainReportName.EndsWith($reportfileending,1))) {
    $mainreportfile = $MainReportName + $reportfileending
}

$mainreportfullpath = Join-Path -Path $ReportSourceFolderPath -ChildPath $mainreportfile

Write-FormattedOutput -text "********** Variables ***********"

Write-FormattedOutput "Main report: $MainReportName"
Write-FormattedOutput "Report folder in reporting services: $ReportFolder"
Write-FormattedOutput "Report source folder path: $ReportSourceFolderPath"
Write-FormattedOutput "Data Sources folder: $DataSourcesFolder"
Write-FormattedOutput "Server to install on: $ReportingServer"
Write-FormattedOutput "Main report filename: $mainreportfile"
Write-FormattedOutput "Main report local path: $mainreportfullpath"

Write-FormattedOutput "*********************"

Write-FormattedOutput "Checking if we can find the folder $ReportSourceFolderPath"

if(!(Test-Path -Path $ReportSourceFolderPath)) {
    throw [System.Exception] "The path $ReportSourceFolderPath is not found or not accessible"
}

Write-FormattedOutput "Succeeded"

Write-FormattedOutput "Checking if we can find the report $mainreportfullpath"

if(!(Test-Path -Path $mainreportfullpath)) {
    throw [System.Exception] "The path $mainreportfullpath is not found or not accessible"
}

Write-FormattedOutput "Succeeded"

# Handle installation / update of reports

Write-FormattedOutput "Checking if we can find the main report $MainReportName under $ReportFolder on $ReportingServer"
$rscontent = Get-FolderContentFromRs -rsservername $ReportingServer -path $ReportFolder -reportname $MainReportName

if($rscontent.Count -eq 0) {
    Write-FormattedOutput "The report was not found on the server so will now install it"
    Write-ReportToRsServer -rsservername $ReportingServer -path $ReportFolder -localpath $mainreportfullpath -Description $Description

    Write-FormattedOutput "Checking if we can find the report $MainReportName under $ReportFolder on $ReportingServer"
    $rscontent = Get-FolderContentFromRs -rsservername $ReportingServer -path $ReportFolder -reportname $MainReportName

    if ($rscontent.Count -ne 1) {
        throw [System.Exception] "The report $MainReportName did not get installed under $ReportFolder on $ReportingServer"
    }

    Write-FormattedOutput "Found the report!"
            
    Write-FormattedOutput "Updating the path to the Data Sources"
    $pathtoreport = "$ReportFolder/$MainReportName"
    Update-DataSourcesPathForReport -rsservername $ReportingServer -fullpath $pathtoreport -datasourcepath $DataSourcesFolder

    Write-FormattedOutput "Finished with configuring the datasources for $pathtoreport"

    # Now add the subreports if there are any
    Write-FormattedOutput "Adding subreports if any are found under $ReportSourceFolderPath with *$reportfileending filter"

    $subreportfiles = Get-ChildItem -Path $ReportSourceFolderPath -Filter "*$reportfileending"
    $subfolderdescription = "Main report: $MainReportName $Description"

    foreach ($subreportfile in $subreportfiles) {
        if($subreportfile.Name -eq $mainreportfile) {
            continue
        }

        Write-FormattedOutput "Adding the subreport $($subreportfile.FullName) to $ReportFolder"
        Write-ReportToRsServer -rsservername $ReportingServer -path $ReportFolder -localpath $subreportfile.FullName -Description $subfolderdescription

        Write-FormattedOutput "Updating the path to the Data Sources"
        $pathtosubreport = "$ReportFolder/$($subreportfile.BaseName)"
        Update-DataSourcesPathForReport -rsservername $ReportingServer -fullpath $pathtosubreport -datasourcepath $DataSourcesFolder        
    }

    # Set subscriptions, check if there are any found in the folder
    Write-FormattedOutput "Setting the subscriptions $subscriptionfilefilter if any are found under $ReportSourceFolderPath"

    $subscriptionfiles = Get-ChildItem -Path $ReportSourceFolderPath -Filter $subscriptionfilefilter
    
    foreach ($subscriptionfile in $subscriptionfiles) {        
        Write-FormattedOutput "Adding the subscription $($subscriptionfile.FullName)"
        
        try {
            New-SubscriptionForReport -rsservername $ReportingServer -path $ReportFolder -subscriptionfile $($subscriptionfile.FullName)            
        }
        catch {
            Write-FormattedOutput "Found a problem with setting the subscription $($subscriptionfile.FullName): $($_.Exception.Message)"
            Write-FormattedOutput "Will delete the installed reports as this is the first time they are installed"
            Remove-ReportsFromRsServer -rsservername $ReportingServer -path $ReportFolder -localpath $ReportSourceFolderPath
            throw (New-Object System.Exception("Failed to set the subscription '$($subscriptionfile.FullName)': $($_.Exception.Message)", $_.Exception))
        }
    }
} else {
    # Update the report

    # Notice that default variables does not get updated and this is by design!
    # See https://dba.stackexchange.com/questions/149665/why-does-ssrs-not-update-a-reports-description

    # Do not forget to add / update the subreports
    $pathtoreport = "$ReportFolder/$MainReportName"

    Write-FormattedOutput "The report was found on the server so we will update it"
    Write-FormattedOutput "Removing the subscriptions for $pathtoreport if any are found"

    Remove-SubscriptionsForReport -rsservername $ReportingServer -fullpath $pathtoreport       

    Write-FormattedOutput "Uploading the report $mainreportfullpath to $ReportFolder with overwrite flag"
    Write-ReportToRsServer -rsservername $ReportingServer -path $ReportFolder -localpath $mainreportfullpath -Description $Description -overwrite

    Write-FormattedOutput "Updating defaultvalues for report parameters if found"
    Update-ValuesForParameterInReport -rsservername $ReportingServer -fullpath $pathtoreport -localpath $mainreportfullpath

    Write-FormattedOutput "Updating the path to the Data Sources"
    Update-DataSourcesPathForReport -rsservername $ReportingServer -fullpath $pathtoreport -datasourcepath $DataSourcesFolder

    Write-FormattedOutput "Adding subreports if any are found under $ReportSourceFolderPath with *$reportfileending filter"

    $subreportfiles = Get-ChildItem -Path $ReportSourceFolderPath -Filter "*$reportfileending"
    $subfolderdescription = "Main report: $MainReportName $Description"

    # Now update the subreports if there are any
    foreach ($subreportfile in $subreportfiles) {
        if($subreportfile.Name -eq $mainreportfile) {
            continue
        }
        $pathtosubreport = "$ReportFolder/$($subreportfile.BaseName)"
        
        $isinstalled = IsReportInstalled -rsservername $ReportingServer -path $ReportFolder -reportname $subreportfile.BaseName
        
        If($isinstalled) {
            Write-FormattedOutput "Removing the subscriptions for $pathtosubreport if any are found"    
            Remove-SubscriptionsForReport -rsservername $ReportingServer -fullpath $pathtosubreport     
        }

        Write-FormattedOutput "Updating the subreport $($subreportfile.FullName) to $ReportFolder with overwrite flag"
        Write-ReportToRsServer -rsservername $ReportingServer -path $ReportFolder -localpath $subreportfile.FullName -Description $subfolderdescription -overwrite 

        Write-FormattedOutput "Updating defaultvalues for parameters if found"
        Update-ValuesForParameterInReport -rsservername $ReportingServer -fullpath $pathtosubreport -localpath $subreportfile.FullName

        Write-FormattedOutput "Updating the path to the Data Sources"
        Update-DataSourcesPathForReport -rsservername $ReportingServer -fullpath $pathtosubreport -datasourcepath $DataSourcesFolder           
    }    

    # Re-add the subscriptions
    Write-FormattedOutput "Setting the subscriptions $subscriptionfilefilter if any are found under $ReportSourceFolderPath"
    $subscriptionfiles = Get-ChildItem -Path $ReportSourceFolderPath -Filter $subscriptionfilefilter
    
    foreach ($subscriptionfile in $subscriptionfiles) {        
        Write-FormattedOutput "Adding the subscription $($subscriptionfile.FullName)"
        New-SubscriptionForReport -rsservername $ReportingServer -path $ReportFolder -subscriptionfile $($subscriptionfile.FullName)
    }

    Write-FormattedOutput "Checking if we should delete any reports by searching for files that match $deletefileending in $ReportSourceFolderPath"
    $reportfilestodelete = Get-ChildItem -Path $ReportSourceFolderPath -Filter "*$deletefileending"
    
    foreach($reportfiletodelete in $reportfilestodelete) {        
        Write-FormattedOutput "Found reports to delete. Working on $($reportfiletodelete.BaseName)"

        Remove-ReportFromRsServer -rsservername $ReportingServer -path $ReportFolder -reportname $reportfiletodelete.BaseName
    }
}

Write-FormattedOutput "Finishing deployment"

