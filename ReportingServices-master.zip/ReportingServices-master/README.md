# ReportingServices

These powershell scripts are used to install reports (.rdl files), and subscriptions on those reports, to Reporting Services 2016. You can also delete reports that are not needed anymore

## Run it locally

Clone the repo and if you have pester you can run the tests in [Tests](.\Tests) but you might need to update the servername.

### Dependencies

The code uses the [powershell module ReportingServicesTools](https://github.com/Microsoft/ReportingServicesTools) but since we cannot download this whenever it is already added in this repo and bundled with the deployscripts.

When running locally you also need to install Pester so in a powershell console use 

```powershell
Install-Module -Name Pester -Force -SkipPublisherCheck 
``` 

## Build and deployment overview of the installation scripts and a report

Below is the diagram of the deployment overview for a .rdl report. The deployment uses deploy scripts that are pushed out to the target servers with a build like for example [the SEB.ReportingServices.DeployScripts build](https://tfs.sebank.se/tfs/MSDE/FundExcecution/_build/index?context=allDefinitions&path=%5C&definitionId=3279&_a=completed). Further on we only want to use one build to deploy the scripts to all servers, where that build will be hosted is not clear yet.


![picture alt](DeploymentOverview.jpg "Deployment Overview")

## How to set up deployment of your report

### Pre-req
If the installationscripts have not been deployed to your target servers then contact Microsoft Automation Team to have this set up first. 

###  Source folder
In your source folder you should have one main report (.rdl file) and x number of subreports. You also have subscriptionfiles or a file for deleting a report, see more on this below. There can also be other files in the source folder but they will not have any impact on the deployment.

### Adding a subscription to a report

Two types of subscriptions are supported now and those are fileshare and email. To add one to your report you add a json file to your source folder ending with `.subscription.json` and copy the json from one of the two subscription examples in [the testfolder](https://github.sebank.se/CoECD/ReportingServices/tree/master/Tests/Testproject/SSRS/TEST_ReportIncorrectOrders) and then update the values to your needs. To get this right can be a little tricky in the beginning but there is a template.subscription.json to show examples on what the values can be.

### Set up a build

Before setting up the deployment you first need to set up a build. In the simplest form you basically only need two steps in the build and that is a copy files step, where you copy the files from $(build.sourcesdirectory) to $(build.artifactstagingdirectory)\ and then a publish artifacts step where you publish the files in $(build.artifactstagingdirectory) to a share like \\tfs-files.sebank.se\msde$\Drops\(yourfolder)\$(Build.DefinitionName). Artifact name can be $(Build.BuildNumber)

For tfs project FundExecution there is also a task group in place where a lot of this is prepared for you. Just add the task "Build Reporting Services 2016 Reports" to your build

### Deployment 

To deploy reports you need to call the deploymentscript "InsertAndUpdateReport.ps1" that should be found on the target server and you can use this [deployment of the testreport](https://tfs.sebank.se/tfs/MSDE/FundExcecution/FundExcecution%20Team/_apps/hub/ms.vss-releaseManagement-web.hub-explorer?definitionId=7&_a=releases) as guide for you. If you cannot open it there are 3 steps:

* A "replace tokens" step to update tokens in **\*.json files, for example for email addresses or filepaths in the subscription files
* A "windows machine file copy" step to copy for example 
``` 
$(System.DefaultWorkingDirectory)/$(Release.DefinitionName)/$(Build.BuildNumber) 
``` 
to a folder on the deploy server
* A "PowerShell on Target Machines" step to run remote powershell on the target server which points to the InsertAndUpdateReport.ps1 script. The arguments here can be for example 
``` 
-MainReportName "$(MainReportName)" -ReportFolder "$(RsReportFolder)" -ReportSourceFolderPath "$(DeployFolder)" -DataSourcesFolder "$(RsDataFolder)" -ReportingServer "$(DeployServer)" -Description "$(Description)" 
```

Notes: 
* If your report has the same name as the folder it resides in you do not need to specify the MainReportName parameter. 
* You can specify a folder on Reporting Services with or without the forward slash so for example "/Internal Reports" or "Internal Reports"
* You are encouraged to add these to the description field `Definition: $(Release.DefinitionName) Release: $(Release.ReleaseName) Environment: $(Release.EnvironmentName)` for better clarity and tracebility in Reporting Services
* Using variable groups makes it easier when you deploy reports in several release pipelines

Also here there is a task group created for FundExecution and that is called "Deploy Reporting Services 2016 Reports". When using it you also need to add some variable groups so all variables can be resolved.

## Working with a subscription 

With the `.subscription.json` file you can add a subscription to your report but there are a few things to think about when working with the file. First of you can use the [template file](https://github.sebank.se/CoECD/ReportingServices/tree/master/Template.subscription.json) as base or to see what values you can use. This template might not be totaly complete so feel free to add examples.

### Want to use "Get value from dataset" 

Depending on where in the subscription you want to set "Get value from dataset" you need to do things differently. If it is in the "Email" or "File Share" section (or "Delivery options" if you are looking in the gui) you need to set the field value to `DATASET=>YOUR_PARAMETER_NAME` for example `DATASET=>FILENAME`. 

But if you want to set "Get value from dataset" in the parameters section (or Report parameters when looking in the gui) you should instead use `    {
        "ParameterName":  "Parameter_name",
        "FieldAlias":  "Parameter_name"
    }` 


### Scheduling the subscription

The aim is to support all the options you have in the gui and your recurrance options are Minute, Daily, Weekly, Monthly, MonthlyDayOfWeek or Once

### Error searching 

If your subscription does not show up in your report, gives an error message when being added or is missing some value then check the following:  

* Is your subscription file ending with `.subscription.json`? If not it will not be picked up.
* Are all the parameters you are using in the subscription file (under the section parameters) found as report parameters in the report? 
* Are you using the right values that Reporting Services expects? RS can be very picky with both case sensitivity and also that in the gui things can be named one thing (Excel) but you need to send in the value `EXCELOPENXML` in the subscription.

## Deleting a report

If you want to delete a report from Reporting Services you need to add an empty file that is named <reportname>.delete. This will then delete the report from the Reporting Services folder you have specified in your deployment step. The first time you install a main report this file will be ignored, it is when a report is updated that it will be handled.